declare module "*.png";
declare module "*.mp4";
declare module "*.jpg";
declare module "*.webp";
declare module "*.svg";
declare module "*.gif";
//필요하면 확장자 명을 위와 같이 추가해주면 됨.
