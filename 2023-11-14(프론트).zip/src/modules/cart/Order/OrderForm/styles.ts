import styled from "@emotion/styled";

// 색상 변수 정의
const primaryColor = "#36364b";
const borderColor = "#e1e1e1";
const grayColor = "#999aa9";
const lightgrayColor = "#f5f6f9";
const blueColor = "#3d4ed7";
const lightblueColor = "#0c9cff";
const darkRedColor = "#e02020";

export const OrderFormContainer = styled.div`
  input,
  select {
    font-family: "Roboto", sans-serif;
    font-weight: 400;
    font-size: 14px;
    color: #36364b;
  }

  section {
    display: flex;
    flex-direction: column;
    gap: 10px;
    width: 900px;
  }

  .contain-payment-header {
    margin-bottom: 20px;
    /* border: 1px solid black; */

    .title {
      display: inline-block;
      margin: 0 15px 0 0;
      font-size: 28px;
      font-weight: 600;
      vertical-align: top;
      line-height: 1;
    }
  }

  /* 주문결제 */
  .wrap-payment {
    /* position: relative; */
    display: flex;
    justify-content: space-between;

    /* 주문결제 입력 폼 */
    .contain-payment-body {
      flex: 1;
      width: 640px;
      /* border: 1px solid red; */
    }

    font-size: 15px;
    font-weight: 400;
  }

  .box-list-payment {
    position: relative;
    /* height: auto; */
    overflow: hidden;
    width: 627px;
    border: 2px solid #f5f6f9;
    margin-bottom: 10px;

    .bookinfo {
      display: flex;
      flex-direction: row;
      justify-content: space-between;

      .text-mobileonly {
        display: none;
      }
      .priceinfo {
        /* flex: 1; */
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        gap: 5px;
        margin: 5px 0px;

        div {
          display: flex;
          flex-direction: row;
          justify-content: space-between;
          gap: 15px;
          font-size: 14px;
        }
        > div:nth-of-type(2) {
          color: rgb(239, 0, 124);
        }

        .icon-tag-pricegubun {
          display: inline-block;
          /* padding: 0 8px; */
          width: 60px;
          height: 22px;
          line-height: 20px;
          font-size: 13px;
          font-weight: 400;
          color: white;
          /* border: 1px solid #bfc1cd; */
          border-radius: 4px;
          background-color: #bfc1cd;
          text-align: center;
        }
      }
    }

    .link-detail {
      display: flex;
      float: left;
      padding: 0 15px;
      text-align: left;
      font-size: 16px;
      font-weight: 400;
      letter-spacing: -0.67px;
    }

    .image {
      display: inline-block;
      margin: 0 23px 0 0;
      width: 110px;
      vertical-align: top;
    }

    .image img {
      display: block;
      width: 110px;
      height: 124px;
      border: 1px solid #e1e1e1;
    }

    .text-webonly {
      display: flex;
      flex-direction: column;
      font-weight: 400;
      max-width: 300px;
    }
    .box-tag-bookgubun {
      margin: 8px 0;
    }

    .icon-tag-bookgubun {
      display: inline-block;
      padding: 0 8px;
      width: auto;
      height: 22px;
      line-height: 20px;
      font-size: 12px;
      font-weight: 400;
      color: #0c9cff;
      border: 1px solid #0c9cff;
      border-radius: 4px;
    }
  }

  /* 주문자 정보 */
  .title-order {
    margin: 0 10px 24px 0;
    padding: 12px 0 12px 24px;
    font-size: 16px;
    font-weight: 700;
    background: ${lightgrayColor};
    border-radius: 8px;
  }

  .box-information-order {
    padding: 0 24px 34px 24px;
    /* gap: 20px; */

    .box-name {
      margin-bottom: 16px;
      width: 316px;
    }

    .box-phonenum {
      display: flex;
      margin-bottom: 16px;
      gap: 10px;
      input {
        width: 120px;
      }
    }

    .box-phonenum .form-text {
      width: 115px;
    }

    .box-email {
      display: flex;
      margin-bottom: 16px;
      vertical-align: middle;
      line-height: 45px;
      gap: 5px;
      input {
        width: 200px;
      }
    }

    .box-memo select {
      background: #fff;
      border-radius: 4px;
      border: 1px solid #e1e1e1;
      cursor: pointer;
      /* font-size: 16px; */
      height: 40px;
      /* margin: 0; */
      margin-top: 12px;
      outline: none;
      padding: 0 30px 3px 16px;
      position: relative;
      vertical-align: middle;
      width: 400px;
      z-index: 1;
    }

    .box-radio {
      margin-bottom: 24px;
      padding: 10px 0 20px 0;
      border-bottom: 1px solid #f5f6f9;
    }

    .text-notice-type1 strong {
      color: #3d4ed7;
    }

    .box-address {
      /* margin-bottom: 16px; */
      display: flex;
      flex-direction: column;
      gap: 10px;

      input[name^="zipcode"] {
        width: 180px;
      }
      input[name^="address"] {
        width: 550px;
      }
      input[name^="street_detail"] {
        width: 550px;
      }

      button {
        padding: 0 28px;
        width: 130px;
        text-align: center;
        font-size: 15px;
        font-weight: 500;
        border-radius: 4px;
        cursor: pointer;
        border: 1px solid ${lightblueColor};
        background: ${lightblueColor};
        color: white;

        /* 마우스 호버 시 스타일 변경 */
        &:hover {
          background: ${blueColor};
          color: white;
        }
      }

      div {
        display: flex;
        gap: 10px;
      }
    }
  }

  .box-information-payment {
    /* margin: -24px 0 48px 0; */

    div:nth-of-type(1) {
      display: flex;
      gap: 10px;
      justify-content: space-between;

      button {
        padding: 0 28px;
        width: 200px;
        height: 56px;
        text-align: center;
        font-size: 15px;
        font-weight: 500;
        border: 1px solid ${grayColor};
        border-radius: 4px;
        box-sizing: border-box;
        cursor: pointer;
        color: ${grayColor};
        background-color: white;

        /* 마우스 호버 시 스타일 변경 */
        &:hover {
          background: ${blueColor};
          color: white;
        }
      }

      .button-selected {
        border: 1px solid ${blueColor};
        color: white;
        background: ${blueColor};
      }
    }

    .payment-tab-cont {
      font-size: 14px;
      strong {
        font-size: 18px;
        font-weight: 500;
        color: ${blueColor};
      }
      margin-bottom: 10px;
    }

    .payment-tab-cont {
      display: none;
    }

    .payment-tab-cont.visible {
      display: block;
    }
  }

  /* 결제 예정금액 sidebar */
  .wrap-payment .box-payment-sidebar {
    position: sticky;
    width: 300px;
    height: 260px;
    right: 0;
    top: 0px; /* 뷰포트 상단에서 고정하기위해 top을 0으로 설정 */
    z-index: 1;
    width: 258px;
    margin-left: auto;
    /* border: 1px solid blue; */

    .contain-calcpay {
      display: block;
      position: relative;
      padding: 24px;
      border: 2px solid #e1e1e1;
      box-sizing: border-box;
      background: #fff;
      border-radius: 8px;
      box-shadow: 4px 18px 18px 3px #00000020;
      /* border: 1px solid red; */
    }

    .title {
      margin-bottom: 24px;
      font-size: 18px;
      font-weight: 500;
    }

    .payment-item {
      display: flex;
      justify-content: space-between;
      margin-bottom: 16px;
    }

    .total {
      margin-top: 10px;
    }

    .total dt {
      font-size: 16px;
      color: #fd342a;
    }

    dt {
      display: flex;
      flex-direction: column;
      justify-content: flex-end;
      font-size: 14px;
      font-weight: 400;
    }

    .div-type2 {
      margin-bottom: 24px;
      display: block;
      margin: 0;
      padding: 0;
      width: 100%;
      height: 1px;
      background: #e1e1e1;
      border: none;
    }
  }

  .box-submit-payment {
    position: relative;
    display: flex;
    justify-content: space-between;
    margin-top: 32px;

    .btn-payment {
      width: 218px;
      height: 44px;
      /* background: #3d4ed7; */
      border: 0;
      border-radius: 4px;
      color: #fff;
      cursor: pointer;
      display: block;
      line-height: 1;
      font-size: 16px;
      font-weight: 500;
      text-align: center;

      background: ${lightblueColor};

      /* 마우스 호버 시 스타일 변경 */
      &:hover {
        background: ${blueColor};
        color: white;
      }
    }
  }

  .box-payment-bottom {
    height: 100px;
  }

  /* 모바일 환경에서만 보이는 스타일 */
  .mobile-only {
    display: none;
  }

  /* 웹 환경에서만 보이는 스타일 */
  .web-only {
    display: block; /* 웹 환경에서 보임 */
  }

  .box-list-payment .bookinfo {
    display: block;
  }
  .box-list-payment .bookinfo-mobileonly {
    display: none;
  }

  .dodal-message-bankdeposit {
    display: flex;
    flex-direction: column;

    p {
      margin-bottom: 10px;
    }
  }
  .dodal-message-bankdeposit .bank-account {
    color: #0057be;
    padding-left: 3px;
  }

  /* 모바일(mobile) 스타일 */
  @media (max-width: 768px) {
    section {
      width: 370px;
      margin: 0px;
    }
    .cart-layer-title {
      display: none;
    }

    .cart-layer {
      flex-direction: column;
      height: 180px;
      align-items: center; /* 수직 가운데 정렬 추가 */
    }

    .bookinfo-mobileonly .book-title {
      margin-top: 5px;
      margin-bottom: 5px;
      font-weight: 600;
    }

    .bookinfo-mobileonly .book-price {
      display: flex;
      flex-direction: row;

      img {
        width: 80px;
        height: 80px;
      }

      > div:nth-of-type(1) {
        width: 15%;
      }
      > div:nth-of-type(2) {
        width: 85%;
      }
      > div:nth-of-type(2) > dl {
        display: flex;
        flex-direction: row;

        dt {
          width: 80px;
        }
        dd {
          margin-left: 5px;
        }
      }
    }
    .icon-tag-pricegubun {
      display: inline-block;
      /* padding: 0 8px; */
      width: 35px;
      height: 20px;
      line-height: 20px;
      font-size: 13px;
      font-weight: 400;
      color: ${grayColor};
      border: 1px solid #bfc1cd;
      border-radius: 4px;
      background-color: ${lightgrayColor};
      text-align: center;
    }

    .box-list-payment .bookinfo {
      display: none;
    }
    .box-list-payment .bookinfo-mobileonly {
      display: block;
    }

    .box-information-order {
      padding: 0 0px 10px 0px;
    }

    /* 주문자명 */
    .box-information-order .box-name {
      input {
        width: 360px;
      }
    }

    /* 주문자 전화번호 */
    .box-information-order .box-phonenum {
      input {
        width: 111px;
      }
    }

    /* 주문자 이메일 */
    .box-information-order .box-email {
      input {
        width: 165px;
      }
    }

    /* 주소 */
    .box-information-order .box-address {
      input[name^="zipcode"] {
        width: 140px;
      }
      input[name^="address"] {
        width: 360px;
      }
      input[name^="street_detail"] {
        width: 360px;
      }
    }

    /* 배송 메모 */
    .box-information-order .box-memo {
      select {
        width: 360px;
      }
      input[name^="delivery-memo"] {
        width: 360px;
      }
    }

    /* 결제 예정금액 sidebar */
    .mobile-only {
      display: block; /* 모바일 환경에서 보임 */
    }

    .web-only {
      display: none; /* 모바일 환경에서 숨김 */
    }

    .wrap-payment {
      /* width: 380px; */
    }
    .wrap-payment .contain-payment-body {
      width: 380px;
    }

    .box-payment-bottom {
      height: 0px;
    }

    .mobile-only {
      > div {
        margin-top: 10px;
        /* border: 1px solid ${grayColor}; */
        /* border-radius: 4px; */
      }
    }

    .payment-item-mobile {
      display: flex;
      flex-direction: row;

      dt {
        width: 150px;
      }
    }

    .box-submit-payment {
      margin-top: 10px;
      margin-bottom: 15px;
    }
    .box-submit-payment .btn-payment {
      width: 360px;
    }
  }
`;
