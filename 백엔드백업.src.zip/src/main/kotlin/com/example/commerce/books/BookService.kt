package com.example.commerce.books

import org.springframework.stereotype.Service

@Service
class BookService {
}