const BookForeignList = () => {
  return <></>;
};

export default BookForeignList;
